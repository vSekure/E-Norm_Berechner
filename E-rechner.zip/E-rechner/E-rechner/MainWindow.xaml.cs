﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace E_rechner
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txt_wert.Focus(); //Fokus setzen
        }

        private void txt_wert_TextChanged(object sender, TextChangedEventArgs e) // Wenn isch etwas an der Einageb ändert aktualisieren 
        {
            BerechneWert();
        }

        private void rbtn_CheckedChanged(object sender, RoutedEventArgs e) // Wenn sich etwas bei den Radio Buttons ändert aktualisieren  
        {
            BerechneWert();
        }

        private void BerechneWert()
        {
            if (string.IsNullOrWhiteSpace(txt_wert.Text)) // Wenn die eingabe leer ist und man löschen drückt stürtzt so das Programm nicht ab 
            {
                lbl_norm.Content = ""; //Wenn die eingabe leer ist den letzen wert aus der ausgabe löschen 
                return;
            }

            if (double.TryParse(txt_wert.Text, out double i)) //einlesen
            {
                double[] e6Values = { 1.0, 1.5, 2.2, 3.3, 4.7, 6.8 }; //Arrays mit den E Norm Werten
                double[] e12Values = { 1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2 };
                double[] e24Values = { 1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0, 3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1 };

                if (rbtn_6.IsChecked == true) // Welcher rbtn gedrückt ist
                {
                    lbl_norm.Content = BerechneNaechstenGroesserenWert(i, e6Values);
                }
                else if (rbtn_12.IsChecked == true)
                {
                    lbl_norm.Content = BerechneNaechstenGroesserenWert(i, e12Values);
                }
                else if (rbtn_24.IsChecked == true)
                {
                    lbl_norm.Content = BerechneNaechstenGroesserenWert(i, e24Values);
                }
            }
        }

        private double BerechneNaechstenGroesserenWert(double wert, double[] werteArray) //Nächst größeren wert hernehmen
        {
            foreach (double val in werteArray)
            {
                if (val >= wert)
                {
                    return val;
                }
            }
            
            return werteArray[werteArray.Length - 1]; // Wenn kein größerer Wert
        }

        private void txt_wert_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e) // Keine Buchstaben zulassen
        {
            char ch = char.Parse(e.Text);

            if (char.IsDigit(ch) || (ch == ','))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void btn_beenden_Click(object sender, RoutedEventArgs e) //Beenden
        {
            if (MessageBox.Show("Wollen sie das Programm wirklich beenden?", "Programm beenden", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Close();
            }
        }
    }
}
